import org.junit.Test;

public class Main {

    @Test
    public void testHelloWrold() {
        System.out.println("HelloWorld!");
    }
}
